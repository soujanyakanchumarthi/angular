import { Component ,OnInit } from '@angular/core';
import { of, Observable, OperatorFunction } from 'rxjs';
import { map} from 'rxjs/operators';
import { Router } from '@angular/router';
import { List,MyserviceService } from './myservice.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'MusicStore';

  service:MyserviceService;
  router:Router;

  constructor(service:MyserviceService,router:Router){
    this.service=service;
    this.router=router;
  }

  ngOnInit(){

    //redirect to album list
  
    this.router.navigate(['app-album-list'])
  }
}
