import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAlbumComponent } from './add-album/add-album.component';
import { AlbumListComponent } from './album-list/album-list.component';



const routes: Routes = [
  {
    path:'app-add-album',
    component:AddAlbumComponent
  },

  {
    path:'app-album-list',
    component:AlbumListComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
