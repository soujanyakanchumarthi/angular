import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  http:HttpClient;
  lists:List[]=[];

  constructor(http:HttpClient) {
    this.http=http;
    this.fetchLists();
   }

   fetched:boolean=false;
   
  fetchLists(){
    this.http.get('./assets/list.json')
    .subscribe(
      data=>{
         if(!this.fetched){
           this.convert(data);
           this.fetched=true;
         }
      }
    );
    }

    getLists():List[]{
      return this.lists;
    }

    convert(data:any)
  {
    for(let obj of data)
    {
      let l=new List(obj.AlbumID,obj.Title,obj.Artist,obj.Price);
      this.lists.push(l);
    }
  }

  delete(AlbumID:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.lists.length;i++)
    {
      let e=this.lists[i];
      if(AlbumID==e.AlbumID)
      {
        foundIndex=i;
        break;
      }
    }
    this.lists.splice(foundIndex,1);
  }

  add(e:List){
    this.lists.push(e);
  }
}

export class List{
  AlbumID:number;
  Title:string;
  Artist:string;
  Price:number;

  constructor( AlbumID:number,Title:string,Artist:string,Price:number)
  {
    this.AlbumID=AlbumID;
    this.Title=Title;
    this.Artist=Artist;
    this.Price=Price;
  }
}