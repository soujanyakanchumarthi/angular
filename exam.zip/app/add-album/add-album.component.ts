import { Component, OnInit } from '@angular/core';
import {MyserviceService , List} from '../myservice.service';
import { of, Observable, OperatorFunction } from 'rxjs';
import { map} from 'rxjs/operators';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  createdList:List;

  createdFlag:boolean=false;

  service:MyserviceService;

  router:Router;

  constructor(service:MyserviceService) { 
    this.service=service;
  }

  ngOnInit() {
    this.router.navigate(['app-album-list'])
  }

  add(data:any){
    this.createdList=new List(data.AlbumID,data.Title,data.Artist,data.Price);
    this.service.add(this.createdList);
    // alert("Added Succesfully!!!");
    this.createdFlag=true;
   }
}
