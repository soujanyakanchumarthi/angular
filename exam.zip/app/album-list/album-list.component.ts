import { Component, OnInit } from '@angular/core';
import { List,MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-album-list',
  templateUrl: './album-list.component.html',
  styleUrls: ['./album-list.component.css']
})
export class AlbumListComponent implements OnInit {
  service:MyserviceService;
  
  constructor(service:MyserviceService) { 
    this.service=service;
  }

  lists: List[];

  delete(AlbumID:number)
  {
    this.service.delete(AlbumID);
    this.lists=this.service.getLists();
    alert("Are you sure you want to delete?");
  }

  ngOnInit() {
    this.service.fetchLists();
    this.lists=this.service.getLists();
  }

}
